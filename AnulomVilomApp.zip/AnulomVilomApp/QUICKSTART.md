# QUICK START GUIDE - Anulom Vilom App

## For Non-Developers (Easy Method)

### What You Need:
1. A computer with Android Studio installed
2. An Android phone (Android 7.0 or higher)
3. A USB cable to connect your phone

### Steps to Install:

**Step 1: Open the Project**
1. Download and extract the AnulomVilomApp folder
2. Open Android Studio
3. Click "Open" → Navigate to AnulomVilomApp folder → Click "OK"
4. Wait 2-5 minutes for the project to load (you'll see progress at the bottom)

**Step 2: Connect Your Phone**
1. On your phone: Go to Settings → About Phone → Tap "Build Number" 7 times
2. Go back → Developer Options → Enable "USB Debugging"
3. Connect your phone to computer with USB cable
4. On phone, tap "Allow" when prompted about USB debugging

**Step 3: Install the App**
1. In Android Studio, click the green "Play" button (▶) at the top
2. Select your device from the list
3. Click "OK"
4. Wait 1-2 minutes for the app to install
5. The app will automatically open on your phone!

---

## For Developers (Build APK)

### Quick Build Command:
```bash
cd AnulomVilomApp
chmod +x gradlew
./gradlew assembleDebug
```

APK Location: `app/build/outputs/apk/debug/app-debug.apk`

### Install APK on Device:
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## Using the App

### First Time:
1. Open "Anulom Vilom" app
2. Default settings are already good: 4-4-4-4 pattern, 5 minutes
3. Tap "Play Music" (optional)
4. Tap "Start"
5. Follow the on-screen breathing instructions!

### Features:
- **Start**: Begin your breathing session
- **Pause**: Take a break (keeps your progress)
- **Stop**: End session and save to reports
- **Play Music**: Calming meditation background sound
- **View Reports**: See all your past sessions

### Tips:
- Start with 3-5 minutes if you're new to pranayama
- Use headphones for better meditation music experience
- Practice in a quiet, comfortable place
- Keep your phone on a stand where you can see it

---

## Troubleshooting

**Problem: Android Studio won't open the project**
- Solution: Make sure you have the latest Android Studio version
- Download from: https://developer.android.com/studio

**Problem: Phone not detected**
- Solution: Try a different USB cable
- Make sure USB Debugging is enabled
- Try changing USB mode to "File Transfer" on phone

**Problem: App crashes on start**
- Solution: Uninstall and reinstall the app
- Make sure your Android version is 7.0 or higher

**Problem: No sound**
- Solution: Check phone volume
- Disable Do Not Disturb mode
- Make sure media volume is up (not just ringer volume)

---

## Support

If you have issues:
1. Check the detailed README.md file
2. Make sure all files are in the correct folders
3. Try "Build → Clean Project" then "Build → Rebuild Project" in Android Studio

---

Enjoy your pranayama practice! 🧘‍♂️
