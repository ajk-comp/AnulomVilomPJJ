# Anulom Vilom Pranayama Android App

A complete Android application for practicing Anulom Vilom (alternate nostril breathing) pranayama with customizable breathing patterns, background meditation music, and detailed session tracking.

## Features

### Core Functionality
- **Customizable Breathing Pattern**: Set individual durations for:
  - Inhale time (in seconds)
  - First hold time (in seconds)
  - Exhale time (in seconds)
  - Second hold time (in seconds)
  - Total session duration (in minutes)

- **Visual Guidance**: 
  - Real-time display of current breathing phase (INHALE, HOLD, EXHALE)
  - Countdown timer showing remaining time for current phase
  - Cycle counter showing progress (Current Cycle / Total Cycles)

- **Session Controls**:
  - Start - Begin breathing session
  - Pause/Resume - Pause and resume session
  - Stop - End session early and save progress

- **Background Meditation Music**:
  - Soothing 432 Hz meditation tone (healing frequency)
  - Play/Pause toggle button
  - Music continues in background
  - Loops continuously during session

- **Session Reports**:
  - Automatic saving of every completed or stopped session
  - Detailed report includes:
    - Date and time of session
    - Breathing pattern used (e.g., 4-4-4-4 seconds)
    - Actual duration of session
    - Number of cycles completed
    - Planned duration
  - View all past sessions
  - Clear all reports option

## Building the APK

### Prerequisites
1. **Android Studio** (Arctic Fox or newer)
   - Download from: https://developer.android.com/studio

2. **JDK 11 or newer**
   - Bundled with Android Studio or download separately

3. **Android SDK**
   - API Level 24 (Android 7.0) minimum
   - API Level 34 (Android 14) target

### Build Steps

#### Method 1: Using Android Studio (Recommended)
1. Open Android Studio
2. Click "Open an Existing Project"
3. Navigate to the `AnulomVilomApp` folder and select it
4. Wait for Gradle sync to complete
5. Build APK:
   - Go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**
   - Or use keyboard shortcut: `Ctrl+B` (Windows/Linux) or `Cmd+B` (Mac)
6. Once complete, click "locate" in the notification to find your APK
7. APK location: `app/build/outputs/apk/debug/app-debug.apk`

#### Method 2: Using Command Line
1. Open terminal/command prompt
2. Navigate to project directory:
   ```bash
   cd AnulomVilomApp
   ```
3. Make gradlew executable (Linux/Mac):
   ```bash
   chmod +x gradlew
   ```
4. Build debug APK:
   ```bash
   ./gradlew assembleDebug
   ```
   Or on Windows:
   ```bash
   gradlew.bat assembleDebug
   ```
5. Find APK at: `app/build/outputs/apk/debug/app-debug.apk`

#### Building Release APK (for distribution)
1. Create a keystore (one-time setup):
   ```bash
   keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias
   ```
2. Build release APK:
   ```bash
   ./gradlew assembleRelease
   ```
3. Sign the APK using your keystore
4. Find APK at: `app/build/outputs/apk/release/app-release-unsigned.apk`

## Installation on Android Device

### Method 1: Direct Install via USB
1. Enable Developer Options on your Android device:
   - Go to Settings → About Phone
   - Tap "Build Number" 7 times
2. Enable USB Debugging:
   - Go to Settings → Developer Options
   - Enable "USB Debugging"
3. Connect device to computer via USB
4. In Android Studio, click the "Run" button (green triangle)
5. Select your device from the list

### Method 2: Install APK File
1. Transfer the APK file to your Android device
2. On your device, open the APK file
3. Allow "Install from Unknown Sources" if prompted
4. Follow installation prompts

## Using the App

### Starting a Session
1. Set your desired breathing pattern:
   - Inhale: 4 seconds (default)
   - Hold: 4 seconds (default)
   - Exhale: 4 seconds (default)
   - Hold: 4 seconds (default)
   - Total Time: 5 minutes (default)
2. (Optional) Tap "Play Music" to start meditation sound
3. Tap "Start" button
4. Follow the on-screen guidance:
   - Watch the status text (INHALE, HOLD, EXHALE)
   - Follow the countdown timer
   - Track your progress with the cycle counter

### During Session
- **Pause**: Tap "Pause" to temporarily stop (tap "Resume" to continue)
- **Stop**: Tap "Stop" to end session early (progress will be saved)
- **Music**: Toggle background music on/off anytime

### Viewing Reports
1. Tap "View Reports" button
2. Browse all your past sessions
3. Each report shows:
   - Date and time
   - Breathing pattern used
   - Duration and cycles completed
4. Tap "Clear All Reports" to delete all history

## Default Settings
- Inhale: 4 seconds
- Hold (after inhale): 4 seconds
- Exhale: 4 seconds
- Hold (after exhale): 4 seconds
- Total Time: 5 minutes
- This creates a balanced 4-4-4-4 breathing pattern

## Recommended Patterns

### Beginner
- 3-3-3-3 (12 seconds per cycle)
- Duration: 3-5 minutes

### Intermediate
- 4-4-4-4 (16 seconds per cycle) - Default
- Duration: 5-10 minutes

### Advanced
- 5-5-5-5 or 6-6-6-6
- Duration: 10-20 minutes

## Technical Details

### Architecture
- **Language**: Java
- **Min SDK**: 24 (Android 7.0)
- **Target SDK**: 34 (Android 14)
- **Architecture Pattern**: Single Activity with RecyclerView

### Libraries Used
- AndroidX AppCompat
- Material Design Components
- ConstraintLayout
- Gson (for JSON serialization)

### Data Storage
- SharedPreferences for session history
- Maximum 100 sessions stored
- JSON serialization via Gson

### Audio
- MediaPlayer for background music
- 432 Hz meditation tone
- WAV format, 30 seconds loop

## File Structure
```
AnulomVilomApp/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/anulomvilom/
│   │       │   ├── MainActivity.java
│   │       │   ├── ReportActivity.java
│   │       │   ├── SessionReport.java
│   │       │   └── SessionDataManager.java
│   │       ├── res/
│   │       │   ├── layout/
│   │       │   │   ├── activity_main.xml
│   │       │   │   ├── activity_report.xml
│   │       │   │   └── item_report.xml
│   │       │   ├── values/
│   │       │   │   ├── colors.xml
│   │       │   │   ├── strings.xml
│   │       │   │   └── styles.xml
│   │       │   ├── drawable/
│   │       │   │   └── ic_launcher.xml
│   │       │   └── raw/
│   │       │       └── meditation_sound.wav
│   │       └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

## Troubleshooting

### Gradle Sync Failed
- Check internet connection
- Try: File → Invalidate Caches / Restart
- Update Android Studio to latest version

### APK Install Failed
- Check if device has enough storage
- Ensure "Install from Unknown Sources" is enabled
- Uninstall previous version if exists

### Music Not Playing
- Check device volume
- Ensure device is not in silent mode
- Some devices may block audio permissions

## Future Enhancements
- Multiple meditation sound options
- Dark mode theme
- Export reports to CSV
- Guided voice instructions
- Widget for quick access
- Reminder notifications
- Statistics and progress charts

## License
This is a sample application created for educational purposes.

## Support
For issues or questions, please contact the developer or create an issue in the project repository.
