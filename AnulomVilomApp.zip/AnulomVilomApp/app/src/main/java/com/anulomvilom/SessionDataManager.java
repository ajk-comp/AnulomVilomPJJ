package com.anulomvilom;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class SessionDataManager {
    
    private static final String PREFS_NAME = "AnulomVilomPrefs";
    private static final String KEY_SESSIONS = "sessions";
    
    public static void saveSession(Context context, SessionReport report) {
        List<SessionReport> sessions = getAllSessions(context);
        sessions.add(0, report); // Add to beginning
        
        // Keep only last 100 sessions
        if (sessions.size() > 100) {
            sessions = sessions.subList(0, 100);
        }
        
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        
        Gson gson = new Gson();
        String json = gson.toJson(sessions);
        editor.putString(KEY_SESSIONS, json);
        editor.apply();
    }
    
    public static List<SessionReport> getAllSessions(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String json = prefs.getString(KEY_SESSIONS, null);
        
        if (json == null) {
            return new ArrayList<>();
        }
        
        Gson gson = new Gson();
        Type type = new TypeToken<List<SessionReport>>(){}.getType();
        List<SessionReport> sessions = gson.fromJson(json, type);
        
        return sessions != null ? sessions : new ArrayList<>();
    }
    
    public static void clearAllSessions(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove(KEY_SESSIONS);
        editor.apply();
    }
}
