package com.anulomvilom;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText etInhale, etHold1, etExhale, etHold2, etTotalTime;
    private Button btnStart, btnPause, btnStop, btnViewReports, btnToggleMusic;
    private TextView tvStatus, tvTimer, tvCycles;
    
    private int inhaleTime, hold1Time, exhaleTime, hold2Time, totalMinutes;
    private int currentCycle = 0;
    private int totalCycles = 0;
    private long sessionStartTime;
    private boolean isRunning = false;
    private boolean isPaused = false;
    private boolean isMusicPlaying = false;
    
    private CountDownTimer breathTimer;
    private MediaPlayer mediaPlayer;
    private BreathingPhase currentPhase = BreathingPhase.IDLE;
    
    private enum BreathingPhase {
        IDLE, INHALE, HOLD1, EXHALE, HOLD2
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initializeViews();
        setupListeners();
        initializeMediaPlayer();
    }

    private void initializeViews() {
        etInhale = findViewById(R.id.etInhale);
        etHold1 = findViewById(R.id.etHold1);
        etExhale = findViewById(R.id.etExhale);
        etHold2 = findViewById(R.id.etHold2);
        etTotalTime = findViewById(R.id.etTotalTime);
        
        btnStart = findViewById(R.id.btnStart);
        btnPause = findViewById(R.id.btnPause);
        btnStop = findViewById(R.id.btnStop);
        btnViewReports = findViewById(R.id.btnViewReports);
        btnToggleMusic = findViewById(R.id.btnToggleMusic);
        
        tvStatus = findViewById(R.id.tvStatus);
        tvTimer = findViewById(R.id.tvTimer);
        tvCycles = findViewById(R.id.tvCycles);
        
        // Set default values
        etInhale.setText("4");
        etHold1.setText("4");
        etExhale.setText("4");
        etHold2.setText("4");
        etTotalTime.setText("5");
        
        btnPause.setEnabled(false);
        btnStop.setEnabled(false);
    }

    private void setupListeners() {
        btnStart.setOnClickListener(v -> startBreathing());
        btnPause.setOnClickListener(v -> togglePause());
        btnStop.setOnClickListener(v -> stopBreathing());
        btnViewReports.setOnClickListener(v -> viewReports());
        btnToggleMusic.setOnClickListener(v -> toggleMusic());
    }

    private void initializeMediaPlayer() {
        try {
            mediaPlayer = MediaPlayer.create(this, R.raw.meditation_sound);
            if (mediaPlayer != null) {
                mediaPlayer.setLooping(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void startBreathing() {
        if (!validateInputs()) {
            return;
        }
        
        inhaleTime = Integer.parseInt(etInhale.getText().toString());
        hold1Time = Integer.parseInt(etHold1.getText().toString());
        exhaleTime = Integer.parseInt(etExhale.getText().toString());
        hold2Time = Integer.parseInt(etHold2.getText().toString());
        totalMinutes = Integer.parseInt(etTotalTime.getText().toString());
        
        int cycleDuration = inhaleTime + hold1Time + exhaleTime + hold2Time;
        totalCycles = (totalMinutes * 60) / cycleDuration;
        currentCycle = 0;
        
        sessionStartTime = System.currentTimeMillis();
        isRunning = true;
        isPaused = false;
        
        disableInputs();
        btnStart.setEnabled(false);
        btnPause.setEnabled(true);
        btnStop.setEnabled(true);
        
        startNextCycle();
    }

    private void startNextCycle() {
        if (currentCycle >= totalCycles) {
            completeSession();
            return;
        }
        
        currentCycle++;
        updateCycleDisplay();
        startPhase(BreathingPhase.INHALE, inhaleTime);
    }

    private void startPhase(BreathingPhase phase, int duration) {
        currentPhase = phase;
        updateStatusText();
        
        if (breathTimer != null) {
            breathTimer.cancel();
        }
        
        breathTimer = new CountDownTimer(duration * 1000L, 100) {
            @Override
            public void onTick(long millisUntilFinished) {
                double secondsLeft = millisUntilFinished / 1000.0;
                tvTimer.setText(String.format(Locale.US, "%.1f", secondsLeft));
            }

            @Override
            public void onFinish() {
                tvTimer.setText("0.0");
                moveToNextPhase();
            }
        }.start();
    }

    private void moveToNextPhase() {
        switch (currentPhase) {
            case INHALE:
                startPhase(BreathingPhase.HOLD1, hold1Time);
                break;
            case HOLD1:
                startPhase(BreathingPhase.EXHALE, exhaleTime);
                break;
            case EXHALE:
                startPhase(BreathingPhase.HOLD2, hold2Time);
                break;
            case HOLD2:
                startNextCycle();
                break;
        }
    }

    private void updateStatusText() {
        String status = "";
        switch (currentPhase) {
            case INHALE:
                status = "INHALE";
                break;
            case HOLD1:
                status = "HOLD";
                break;
            case EXHALE:
                status = "EXHALE";
                break;
            case HOLD2:
                status = "HOLD";
                break;
            case IDLE:
                status = "Ready";
                break;
        }
        tvStatus.setText(status);
    }

    private void updateCycleDisplay() {
        tvCycles.setText(String.format(Locale.US, "Cycle: %d / %d", currentCycle, totalCycles));
    }

    private void togglePause() {
        if (isPaused) {
            // Resume
            isPaused = false;
            btnPause.setText("Pause");
            // Continue from current phase
            if (currentPhase != BreathingPhase.IDLE) {
                // Restart current phase with remaining time
                int duration = 0;
                switch (currentPhase) {
                    case INHALE: duration = inhaleTime; break;
                    case HOLD1: duration = hold1Time; break;
                    case EXHALE: duration = exhaleTime; break;
                    case HOLD2: duration = hold2Time; break;
                }
                startPhase(currentPhase, duration);
            }
        } else {
            // Pause
            isPaused = true;
            btnPause.setText("Resume");
            if (breathTimer != null) {
                breathTimer.cancel();
            }
        }
    }

    private void stopBreathing() {
        if (breathTimer != null) {
            breathTimer.cancel();
        }
        
        long sessionDuration = (System.currentTimeMillis() - sessionStartTime) / 1000;
        saveSessionReport(sessionDuration);
        
        resetUI();
    }

    private void completeSession() {
        long sessionDuration = (System.currentTimeMillis() - sessionStartTime) / 1000;
        saveSessionReport(sessionDuration);
        
        Toast.makeText(this, "Session completed!", Toast.LENGTH_LONG).show();
        resetUI();
    }

    private void saveSessionReport(long durationSeconds) {
        SessionReport report = new SessionReport();
        report.date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
        report.inhaleTime = inhaleTime;
        report.hold1Time = hold1Time;
        report.exhaleTime = exhaleTime;
        report.hold2Time = hold2Time;
        report.totalMinutes = totalMinutes;
        report.cyclesCompleted = currentCycle;
        report.actualDurationSeconds = durationSeconds;
        
        SessionDataManager.saveSession(this, report);
        Toast.makeText(this, "Session saved to reports", Toast.LENGTH_SHORT).show();
    }

    private void resetUI() {
        isRunning = false;
        isPaused = false;
        currentPhase = BreathingPhase.IDLE;
        currentCycle = 0;
        
        tvStatus.setText("Ready");
        tvTimer.setText("0.0");
        tvCycles.setText("Cycle: 0 / 0");
        
        btnStart.setEnabled(true);
        btnPause.setEnabled(false);
        btnPause.setText("Pause");
        btnStop.setEnabled(false);
        
        enableInputs();
    }

    private void toggleMusic() {
        if (mediaPlayer == null) {
            Toast.makeText(this, "Music not available", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if (isMusicPlaying) {
            mediaPlayer.pause();
            btnToggleMusic.setText("Play Music");
            isMusicPlaying = false;
        } else {
            mediaPlayer.start();
            btnToggleMusic.setText("Pause Music");
            isMusicPlaying = true;
        }
    }

    private void viewReports() {
        Intent intent = new Intent(this, ReportActivity.class);
        startActivity(intent);
    }

    private boolean validateInputs() {
        try {
            int inhale = Integer.parseInt(etInhale.getText().toString());
            int hold1 = Integer.parseInt(etHold1.getText().toString());
            int exhale = Integer.parseInt(etExhale.getText().toString());
            int hold2 = Integer.parseInt(etHold2.getText().toString());
            int total = Integer.parseInt(etTotalTime.getText().toString());
            
            if (inhale <= 0 || hold1 <= 0 || exhale <= 0 || hold2 <= 0 || total <= 0) {
                Toast.makeText(this, "All values must be greater than 0", Toast.LENGTH_SHORT).show();
                return false;
            }
            
            return true;
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private void disableInputs() {
        etInhale.setEnabled(false);
        etHold1.setEnabled(false);
        etExhale.setEnabled(false);
        etHold2.setEnabled(false);
        etTotalTime.setEnabled(false);
    }

    private void enableInputs() {
        etInhale.setEnabled(true);
        etHold1.setEnabled(true);
        etExhale.setEnabled(true);
        etHold2.setEnabled(true);
        etTotalTime.setEnabled(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (breathTimer != null) {
            breathTimer.cancel();
        }
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mediaPlayer != null && isMusicPlaying) {
            mediaPlayer.pause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mediaPlayer != null && isMusicPlaying) {
            mediaPlayer.start();
        }
    }
}
