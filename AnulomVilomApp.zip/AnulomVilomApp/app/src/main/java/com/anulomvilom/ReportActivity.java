package com.anulomvilom;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ReportActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TextView tvNoData;
    private Button btnClearAll;
    private ReportAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Session Reports");
        
        recyclerView = findViewById(R.id.recyclerView);
        tvNoData = findViewById(R.id.tvNoData);
        btnClearAll = findViewById(R.id.btnClearAll);
        
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        loadReports();
        
        btnClearAll.setOnClickListener(v -> {
            SessionDataManager.clearAllSessions(this);
            loadReports();
        });
    }

    private void loadReports() {
        List<SessionReport> sessions = SessionDataManager.getAllSessions(this);
        
        if (sessions.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            tvNoData.setVisibility(View.VISIBLE);
            btnClearAll.setEnabled(false);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            tvNoData.setVisibility(View.GONE);
            btnClearAll.setEnabled(true);
            
            adapter = new ReportAdapter(sessions);
            recyclerView.setAdapter(adapter);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    private static class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ViewHolder> {
        
        private List<SessionReport> reports;
        
        public ReportAdapter(List<SessionReport> reports) {
            this.reports = reports;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_report, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            SessionReport report = reports.get(position);
            
            holder.tvDate.setText(report.date);
            holder.tvPattern.setText("Pattern: " + report.getBreathingPattern() + " seconds");
            holder.tvDuration.setText("Duration: " + report.getFormattedDuration());
            holder.tvCycles.setText("Cycles: " + report.cyclesCompleted);
            holder.tvPlanned.setText("Planned: " + report.totalMinutes + " minutes");
        }

        @Override
        public int getItemCount() {
            return reports.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvDate, tvPattern, tvDuration, tvCycles, tvPlanned;

            ViewHolder(View itemView) {
                super(itemView);
                tvDate = itemView.findViewById(R.id.tvDate);
                tvPattern = itemView.findViewById(R.id.tvPattern);
                tvDuration = itemView.findViewById(R.id.tvDuration);
                tvCycles = itemView.findViewById(R.id.tvCycles);
                tvPlanned = itemView.findViewById(R.id.tvPlanned);
            }
        }
    }
}
