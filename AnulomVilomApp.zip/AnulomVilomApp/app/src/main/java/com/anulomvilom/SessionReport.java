package com.anulomvilom;

public class SessionReport {
    public String date;
    public int inhaleTime;
    public int hold1Time;
    public int exhaleTime;
    public int hold2Time;
    public int totalMinutes;
    public int cyclesCompleted;
    public long actualDurationSeconds;
    
    public SessionReport() {
    }
    
    public String getFormattedDuration() {
        long minutes = actualDurationSeconds / 60;
        long seconds = actualDurationSeconds % 60;
        return String.format("%d min %d sec", minutes, seconds);
    }
    
    public String getBreathingPattern() {
        return String.format("%d-%d-%d-%d", inhaleTime, hold1Time, exhaleTime, hold2Time);
    }
}
